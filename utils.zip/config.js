module.exports = {
    httpMethods: [
        'POST',
        'PUT',
        'PATCH',
        'DELETE'
    ],
    HttpStatusCodes:{
        internalServerError:500,
        notFound:404,
    },
    port:3000
}